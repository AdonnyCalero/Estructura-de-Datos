#include "Huesped.h"
#include <iostream>

using namespace std;

Huesped::Huesped() {
    nombre = "";
    apellido = "";
    cedula = "";
    correo = "";
}

Huesped::Huesped(string nombre, string apellido, string cedula, string correo) {
    this->nombre = nombre;
    this->apellido = apellido;
    this->cedula = cedula;
    this->correo = correo;
}

void Huesped::setNombre(const string& nombre) {
    this->nombre = nombre;
}

void Huesped::setApellido(const string& apellido) {
    this->apellido = apellido;
}

void Huesped::setCedula(const string& cedula) {
    this->cedula = cedula;
}

void Huesped::setCorreo(const string& correo) {
    this->correo = correo;
}

string Huesped::getNombre() const {
    return nombre;
}

string Huesped::getApellido() const {
    return apellido;
}

string Huesped::getCedula() const {
    return cedula;
}

string Huesped::getCorreo() const {
    return correo;
}

ostream& operator<<(ostream& os, const Huesped& huesped) {
    os << "Nombre: " << huesped.getNombre() << "\n"
       << "Apellido: " << huesped.getApellido() << "\n"
       << "Cédula: " << huesped.getCedula() << "\n"
       << "Correo: " << huesped.getCorreo() << "\n";
    return os;
}