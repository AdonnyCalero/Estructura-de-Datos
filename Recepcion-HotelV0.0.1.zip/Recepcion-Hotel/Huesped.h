#ifndef HUESPED_H
#define HUESPED_H

#include <iostream>
#include <string>

using namespace std;

class Huesped {
private:
    string nombre;
    string apellido;
    string cedula;
    string correo;

public:
    Huesped();
    Huesped(string nombre, string apellido, string cedula, string correo);

    void setNombre(const string& nombre);
    void setApellido(const string& apellido);
    void setCedula(const string& cedula);
    void setCorreo(const string& correo);

    string getNombre() const;
    string getApellido() const;
    string getCedula() const;
    string getCorreo() const;

    friend ostream& operator<<(ostream& os, const Huesped& huesped);
};

#endif // HUESPED_H