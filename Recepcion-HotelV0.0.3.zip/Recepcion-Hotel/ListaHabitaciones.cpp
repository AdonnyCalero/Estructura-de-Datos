#include "ListaHabitaciones.h"

ListaHabitaciones::ListaHabitaciones() : cabeza(nullptr) {}

void ListaHabitaciones::agregarHabitacion(int numero, const std::string &tipo, double precio) {
    Habitacion hab(numero, tipo, precio);  // ✅ Pasamos los tres argumentos requeridos
    NodoHabitacion *nuevo = new NodoHabitacion(hab);
    
    if (!cabeza) {
        cabeza = nuevo;
        cabeza->siguiente = cabeza;
        cabeza->anterior = cabeza;
    } else {
        NodoHabitacion *ultimo = cabeza->anterior;
        ultimo->siguiente = nuevo;
        nuevo->anterior = ultimo;
        nuevo->siguiente = cabeza;
        cabeza->anterior = nuevo;
    }
}

Habitacion* ListaHabitaciones::buscarHabitacionPorTipo(const std::string &tipo) {
    if (!cabeza) return nullptr;
    NodoHabitacion *actual = cabeza;
    do {
        if (!actual->habitacion.isOcupada() && actual->habitacion.getTipo() == tipo) {
            return &actual->habitacion;
        }
        actual = actual->siguiente;
    } while (actual != cabeza);
    return nullptr; // No hay habitaciones disponibles del tipo solicitado
}


void ListaHabitaciones::mostrarHabitaciones() {
    if (!cabeza) {
        std::cout << "No hay habitaciones disponibles.\n";
        return;
    }
    NodoHabitacion *actual = cabeza;
    do {
        std::cout << "Habitacion " << actual->habitacion.getNumero() << " - "
                  << (actual->habitacion.isOcupada() ? "Ocupada" : "Libre") << std::endl;
        actual = actual->siguiente;
    } while (actual != cabeza);
}
