#pragma once

#include <string>

class Habitacion {
private:
    int numero;
    bool ocupada;
    std::string cedulaHuesped;
    std::string tipo;
    double precio;

public:
    Habitacion(int num, std::string tipo, double precio) 
    : numero(num), ocupada(false), tipo(tipo), precio(precio), cedulaHuesped("") {}

    int getNumero() const { return numero; }
    bool isOcupada() const { return ocupada; }
    std::string getCedulaHuesped() const { return cedulaHuesped; }
    std::string getTipo() const { return tipo; }
    double getPrecio() const { return precio; }

    void asignarHuesped(const std::string &cedula) {
        ocupada = true;
        cedulaHuesped = cedula;
    }

    void liberar() {
        ocupada = false;
        cedulaHuesped = "";
    }
};