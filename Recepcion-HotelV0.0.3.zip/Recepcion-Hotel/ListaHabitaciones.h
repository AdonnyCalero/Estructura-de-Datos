#pragma once

#include "Habitacion.h"
#include <iostream>

class NodoHabitacion {
public:
    Habitacion habitacion;
    NodoHabitacion *siguiente;
    NodoHabitacion *anterior;

    NodoHabitacion(Habitacion hab) : habitacion(hab), siguiente(nullptr), anterior(nullptr) {}
};

class ListaHabitaciones {
private:
    NodoHabitacion *cabeza;

public:
    ListaHabitaciones();
    void agregarHabitacion(int numero, const std::string &tipo, double precio);
    Habitacion* buscarHabitacionPorTipo(const std::string &tipo);
    void mostrarHabitaciones();
};
